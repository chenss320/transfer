[h2console](https://bitbucket.org/berkeleylab/nest-h2console) provides the necessary files in order to web-enable the H2 database instance that is part of the JBoss AS7.

Once the created WAR file has been deployed the console can be found at: [http://localhost:8080/h2console/h2](http://localhost:8080/h2console/h2)
